import os
import pandas as pd
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt

# 데이터 경로 목록 (테스트용 - 첫 번째 경로만)
data_paths = [
    r"Rawdata\250207_250307_3_김동진_1689mAh_ATL Q7M Inner 2C 상온수명 1-100cyc"
]

# 모든 데이터 포인트와 모든 컬럼 수집
all_data = []
first_datetime = None
total_data_points = 0
files_processed = 0

print("테스트: 다중 채널 데이터 처리 시작...")

# 각 경로별로 처리
for path_idx, base_path in enumerate(data_paths, 1):
    print(f"\n[{path_idx}/{len(data_paths)}] 처리 중: {os.path.basename(base_path)}")

    # 하위 디렉토리 찾기
    existing_subdirs = []
    if os.path.exists(base_path):
        for item in os.listdir(base_path):
            item_path = os.path.join(base_path, item)
            if os.path.isdir(item_path) and item.isdigit():
                existing_subdirs.append(item)

    print(f"  발견된 하위 디렉토리: {', '.join(sorted(existing_subdirs))}")

    # 하위 디렉토리 탐색 (테스트용으로 10개 파일만)
    for subdir in sorted(existing_subdirs):
        subdir_path = os.path.join(base_path, subdir)
        if not os.path.exists(subdir_path):
            continue

        # 각 하위 디렉토리의 파일들 처리 (테스트용으로 10개만)
        for i in range(1, 11):
            file_path = os.path.join(subdir_path, f"{i:06d}")
            if os.path.exists(file_path):
                files_processed += 1
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()

                # 모든 데이터 라인 처리
                for line in lines[4:]:
                    if '2025/02/' in line:
                        parts = line.strip().split(',')
                        if len(parts) >= 16:
                            try:
                                # 날짜와 시간
                                date_str = parts[0]
                                time_str = parts[1]
                                datetime_str = f"{date_str} {time_str}"
                                current_datetime = datetime.strptime(datetime_str, "%Y/%m/%d %H:%M:%S")

                                # 첫 번째 시간 저장
                                if first_datetime is None:
                                    first_datetime = current_datetime

                                # 경과 시간 계산 (시간 단위)
                                elapsed_time = (current_datetime - first_datetime).total_seconds() / 3600.0

                                # 모든 필드 파싱
                                passtime_sec = int(parts[2])
                                voltage = float(parts[3].replace('+', ''))
                                current = float(parts[4].replace('+', '')) if parts[4] else 0.0
                                temp1_first = float(parts[7].replace('+', '')) if parts[7] else 0.0
                                condition = int(parts[11].strip())
                                mode = int(parts[12].strip())
                                cycle = int(parts[13].strip())
                                total_cycle = int(parts[14].strip())

                                all_data.append({
                                    'path_name': os.path.basename(base_path),
                                    'path_idx': path_idx,
                                    'channel': int(subdir),
                                    'file_num': i,
                                    'subdir': subdir,
                                    'date': date_str,
                                    'time': time_str,
                                    'datetime': current_datetime,
                                    'passtime_sec': passtime_sec,
                                    'elapsed_hours': elapsed_time,
                                    'voltage': voltage,
                                    'current': current,
                                    'temperature': temp1_first,
                                    'condition': condition,
                                    'mode': mode,
                                    'cycle': cycle,
                                    'total_cycle': total_cycle
                                })
                                total_data_points += 1

                            except (ValueError, IndexError) as e:
                                continue

print(f"\n테스트 완료!")
print(f"총 읽은 파일 수: {files_processed}")
print(f"총 데이터 포인트: {total_data_points}")

if all_data:
    # DataFrame 생성
    df = pd.DataFrame(all_data)

    # 채널별 데이터 분리
    ch30_data = df[df['channel'] == 30]
    ch31_data = df[df['channel'] == 31]

    print(f"\n채널 30 데이터: {len(ch30_data)} points")
    print(f"채널 31 데이터: {len(ch31_data)} points")

    # 기본 정보 출력
    print(f"\n=== 테스트 데이터 요약 ===")
    print(f"컬럼: {', '.join(df.columns)}")
    print(f"총 행 수: {len(df)}")

    # CSV로 저장 (테스트)
    df.to_csv('outputs/test_multichannel_data.csv', index=False)
    print(f"테스트 데이터가 'outputs/test_multichannel_data.csv'에 저장되었습니다.")

else:
    print("데이터를 읽을 수 없습니다.")